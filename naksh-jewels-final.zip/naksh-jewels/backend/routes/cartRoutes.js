const router = require("express").Router();

let cart = [];

router.post("/", (req, res) => {
  const { productId, quantity } = req.body;

  if (!productId || !quantity) {
    return res.status(400).json({ message: "Invalid data" });
  }

  cart.push({ productId, quantity });
  res.json({ message: "Added to cart", cart });
});

module.exports = router;
