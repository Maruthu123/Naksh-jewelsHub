exports.addToCart = (req, res) => {
  const { productId, qty } = req.body;

  if (!productId || !qty) {
    return res.status(400).json({ error: "productId and qty required" });
  }

  res.json({ message: "Item added to cart" });
};
