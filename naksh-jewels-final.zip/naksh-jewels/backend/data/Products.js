module.exports = [
  { name: "Royal Gold Ring", price: 5200, image: "ring.jpg" },
  { name: "Diamond Necklace", price: 15000, image: "necklace.jpg" },
  { name: "Temple Bangles", price: 8700, image: "bangles.jpg" },
  { name: "Pearl Choker", price: 7600, image: "choker.jpg" }
];
