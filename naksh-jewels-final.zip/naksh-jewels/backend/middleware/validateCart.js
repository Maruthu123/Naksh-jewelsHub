module.exports = (req, res, next) => {
  const { productId, qty } = req.body;

  if (!productId || qty <= 0) {
    return res.status(400).json({ error: "Invalid cart data" });
  }

  next();
};
