// src/pages/Home.jsx - FULL WORKING CODE (No Errors)
import { useState, useEffect } from "react";
import { useCart } from "../context/CartContext";
import "./styles.css";

const products = [
  { id: 1, name: "Royal Gold Ring", price: 5200, image: "ring1.jpg", category: "featured" },
  { id: 2, name: "Diamond Necklace", price: 15000, image: "https://images.unsplash.com/photo-1617038220319-276d3cfab638?auto=format&fit=crop&w=500&q=80", category: "featured" },
  { id: 3, name: "Temple Bangles", price: 8700, image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=500&q=80", category: "featured" },
  { id: 4, name: "Pearl Choker", price: 7600, image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&w=500&q=80", category: "featured" },
  { id: 5, name: "Bridal Haram", price: 28000, image: "bridel.jpg", category: "featured" },
  { id: 6, name: "Gold Bracelet", price: 6400, image: "Gold Bracelet.jpg", category: "premium" },
  { id: 7, name: "Stud Earrings", price: 2800, image: "Stud Earrings.jpg", category: "premium" },
  { id: 8, name: "Luxury Diamond Ring", price: 30000, image: "https://images.unsplash.com/photo-1596944924616-7b38e7cfac36?auto=format&fit=crop&w=500&q=80", category: "premium" },
  { id: 9, name: "Traditional Jhumka", price: 4200, image: "https://images.unsplash.com/photo-1620119896346-0f4f3a89ce74?auto=format&fit=crop&w=500&q=80", category: "premium" },
  { id: 10, name: "Classic Gold Chain", price: 13200, image: "https://images.unsplash.com/photo-1599458252573-56ae36120de7?auto=format&fit=crop&w=500&q=80", category: "premium" },
  { id: 11, name: "Ruby Necklace", price: 25000, image: "https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=500&q=80", category: "wedding" },
  { id: 12, name: "Emerald Earrings", price: 9800, image: "https://images.unsplash.com/photo-1589128777073-263566ae5e4d?auto=format&fit=crop&w=500&q=80", category: "wedding" },
  { id: 13, name: "Designer Anklet", price: 4100, image: "https://images.unsplash.com/photo-1617038154433-8f9dbe8c8f7f?auto=format&fit=crop&w=500&q=80", category: "wedding" },
  { id: 14, name: "Heart Pendant", price: 2900, image: "https://images.unsplash.com/photo-1603974372039-adc49044b6bd?auto=format&fit=crop&w=500&q=80", category: "wedding" },
  { id: 15, name: "Wedding Combo Set", price: 45000, image: "https://images.unsplash.com/photo-1602751584552-8ba73aad10e1?auto=format&fit=crop&w=500&q=80", category: "wedding" }
];

function ProductCard({ product, addToCart }) {
  return (
    <div className="product-card">
      <div className="product-image">
        <img src={product.image} alt={product.name} />
      </div>
      <div className="product-info">
        <h3>{product.name}</h3>
        <span className="price">₹{product.price.toLocaleString()}</span>
        <button 
          className="add-cart-btn"
          onClick={() => addToCart(product)}
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}

export default function Home() {
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const { addToCart } = useCart();

  useEffect(() => {
    setTimeout(() => setLoading(false), 1500);
  }, []);

  const filteredProducts = products.filter(p => 
    filter === 'all' || p.category === filter
  );

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="loading-spinner"></div>
        <p>Loading JewelsHub...</p>
      </div>
    );
  }

  return (
    <div className="home-wrapper">
      {/* HERO SECTION */}
      <section className="hero">
        <div className="hero-bg"></div>
        <div className="hero-content">
          <div className="hero-badge">New Collection 2026</div>
          <h1 className="hero-title">
            Timeless <span className="gradient-text">Elegance</span>
          </h1>
          <p className="hero-subtitle">
            Discover premium handcrafted jewelry for every special moment in your life
          </p>
          <div className="hero-buttons">
            <a href="#featured" className="btn btn-primary">
              Shop Now <span>→</span>
            </a>
            <a href="#premium" className="btn btn-secondary">
              View Collection
            </a>
          </div>
        </div>
        <div className="hero-particles">
          {[...Array(12)].map((_, i) => (
            <span key={i} className={`particle p${i + 1}`}></span>
          ))}
        </div>
      </section>

      {/* FILTERS */}
      <section className="filters-section container">
        <div className="filters">
          <button 
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`} 
            onClick={() => setFilter('all')}
          >
            All
          </button>
          <button 
            className={`filter-btn ${filter === 'featured' ? 'active' : ''}`} 
            onClick={() => setFilter('featured')}
          >
            Featured
          </button>
          <button 
            className={`filter-btn ${filter === 'premium' ? 'active' : ''}`} 
            onClick={() => setFilter('premium')}
          >
            Premium
          </button>
          <button 
            className={`filter-btn ${filter === 'wedding' ? 'active' : ''}`} 
            onClick={() => setFilter('wedding')}
          >
            Wedding
          </button>
        </div>
      </section>

      {/* PRODUCTS */}
      <section id="featured" className="container product-section">
        <div className="section-header">
          <h2 className="section-title">🔥 Featured Collections</h2>
          <a href="/collections" className="view-all">View All →</a>
        </div>
        <div className="product-grid">
          {filteredProducts.slice(0, 8).map((product) => (
            <ProductCard 
              key={product.id} 
              product={product}
              addToCart={addToCart}
            />
          ))}
        </div>
      </section>

      {/* STATS */}
      <section className="stats-section">
        <div className="container">
          <div className="stats-grid">
            <div className="stat-item">
              <div className="stat-number">10K+</div>
              <div className="stat-label">Happy Customers</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">500+</div>
              <div className="stat-label">Unique Designs</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">24K</div>
              <div className="stat-label">Gold Purity</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">5★</div>
              <div className="stat-label">Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* NEWSLETTER */}
      <section className="newsletter-section">
        <div className="container">
          <div className="newsletter-content">
            <h3>Ready to find your perfect piece?</h3>
            <p>Get 10% off your first order</p>
            <div className="newsletter-form">
              <input type="email" placeholder="Enter your email" />
              <button className="btn btn-primary">Subscribe</button>
            </div>
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="container">
          <p>&copy; 2026 Naksh Jewels. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
