export default function NotFound() {
  return <h2 style={{ textAlign: "center" }}>404 Page Not Found</h2>;
}
