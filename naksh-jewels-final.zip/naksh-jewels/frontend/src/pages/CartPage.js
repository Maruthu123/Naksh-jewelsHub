import { useCart } from "../context/CartContext";
import { useState } from "react";

export default function CartPage() {
  const { cart, removeFromCart, updateQty, total } = useCart();
  const [clearConfirm, setClearConfirm] = useState(false);

  const increase = (id, qty) => updateQty(id, qty + 1);
  const decrease = (id, qty) => qty > 1 && updateQty(id, qty - 1);

  const handleClearCart = () => {
    if (clearConfirm) {
      cart.forEach(item => removeFromCart(item.id));
      setClearConfirm(false);
    } else {
      setClearConfirm(true);
      setTimeout(() => setClearConfirm(false), 3000);
    }
  };

  const styles = {
    page: {
      minHeight: "100vh",
      padding: "4rem 5%",
      background: "linear-gradient(135deg,#f8fafc,#e2e8f0)"
    },
    title: {
      textAlign: "center",
      fontSize: "clamp(28px,4vw,36px)",
      fontWeight: 700,
      marginBottom: 40,
      background: "linear-gradient(135deg,#1e3a8a,#38bdf8,#0ea5e9)",
      WebkitBackgroundClip: "text",
      WebkitTextFillColor: "transparent"
    },
    empty: {
      textAlign: "center",
      padding: "80px 20px"
    },
    grid: {
      display: "grid",
      gap: 24
    },
    card: {
      background: "rgba(255,255,255,0.95)",
      borderRadius: 24,
      padding: 24,
      display: "grid",
      gridTemplateColumns: "120px 1fr auto",
      gap: 20,
      alignItems: "center",
      boxShadow: "0 20px 40px rgba(0,0,0,0.08)"
    },
    image: {
      width: "100%",
      height: 120,
      objectFit: "cover",
      borderRadius: 16
    },
    name: {
      fontSize: 18,
      fontWeight: 600,
      marginBottom: 8
    },
    price: {
      fontSize: 20,
      fontWeight: 700,
      color: "#2563eb",
      marginBottom: 12
    },
    qtyBox: {
      display: "flex",
      gap: 12,
      alignItems: "center",
      marginBottom: 12
    },
    qtyBtn: {
      width: 36,
      height: 36,
      borderRadius: 10,
      border: "none",
      color: "white",
      fontSize: 18,
      fontWeight: 700,
      cursor: "pointer"
    },
    total: {
      fontWeight: 700,
      fontSize: 18,
      color: "#1e3a8a"
    },
    remove: {
      width: 48,
      height: 48,
      borderRadius: 16,
      border: "none",
      cursor: "pointer",
      background: "linear-gradient(135deg,#ef4444,#dc2626)",
      color: "white"
    },
    summary: {
      marginTop: 60,
      background: "rgba(255,255,255,0.95)",
      padding: 32,
      borderRadius: 24,
      maxWidth: 500,
      marginInline: "auto",
      boxShadow: "0 20px 40px rgba(0,0,0,0.08)"
    },
    row: {
      display: "flex",
      justifyContent: "space-between",
      marginBottom: 16
    },
    checkout: {
      marginTop: 24,
      padding: "18px",
      textAlign: "center",
      background: "linear-gradient(135deg,#10b981,#059669)",
      color: "white",
      fontWeight: 700,
      borderRadius: 16,
      textDecoration: "none",
      display: "block"
    },
    clear: {
      marginTop: 16,
      padding: "14px",
      width: "100%",
      borderRadius: 12,
      border: "none",
      fontWeight: 600,
      cursor: "pointer",
      color: "white",
      background: clearConfirm
        ? "linear-gradient(135deg,#ef4444,#dc2626)"
        : "linear-gradient(135deg,#6b7280,#4b5563)"
    }
  };

  return (
    <div style={styles.page}>
      <h2 style={styles.title}>Your Shopping Cart</h2>

      {cart.length === 0 ? (
        <div style={styles.empty}>
          <div style={{ fontSize: "6rem" }}>🛒</div>
          <h3>Your cart is empty</h3>
        </div>
      ) : (
        <>
          <div style={styles.grid}>
            {cart.map(item => (
              <div key={item.id} style={styles.card}>
                <img src={item.image} alt={item.name} style={styles.image} />

                <div>
                  <div style={styles.name}>{item.name}</div>
                  <div style={styles.price}>₹{item.price}</div>

                  <div style={styles.qtyBox}>
                    <button
                      style={{ ...styles.qtyBtn, background: "#dc2626" }}
                      onClick={() => decrease(item.id, item.qty)}
                    >-</button>

                    <strong>{item.qty}</strong>

                    <button
                      style={{ ...styles.qtyBtn, background: "#059669" }}
                      onClick={() => increase(item.id, item.qty)}
                    >+</button>
                  </div>

                  <div style={styles.total}>
                    ₹{item.price * item.qty}
                  </div>
                </div>

                <button
                  style={styles.remove}
                  onClick={() => removeFromCart(item.id)}
                >✕</button>
              </div>
            ))}
          </div>

          <div style={styles.summary}>
            <div style={styles.row}>
              <span>Subtotal</span>
              <strong>₹{total}</strong>
            </div>
            <div style={styles.row}>
              <span>Tax (5%)</span>
              <strong>₹{Math.round(total * 0.05)}</strong>
            </div>
            <div style={{ ...styles.row, fontSize: 22 }}>
              <strong>Total</strong>
              <strong>₹{Math.round(total * 1.05)}</strong>
            </div>

            <a href="/checkout" style={styles.checkout}>
              Proceed to Checkout
            </a>

            <button style={styles.clear} onClick={handleClearCart}>
              {clearConfirm ? "Click Again to Clear All" : "Clear Cart"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
