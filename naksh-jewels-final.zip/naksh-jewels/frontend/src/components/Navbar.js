// src/components/Navbar.jsx (rename pannunga .js → .jsx)
import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import "./Navbar.css"; 

export default function Navbar() {  // 👈 இது சரி
  const { cart } = useCart();

  return (
    <nav className="navbar">
      <div className="nav-container">
        <div className="logo">✨ Naksh Jewels</div>
        <div className="nav-links">
          <Link to="/" className="nav-link active">Home</Link>
          <Link to="/cart" className="nav-link">Cart</Link>
         
        </div>
        <div className="nav-actions">
          <button className="search-btn">🔍</button>
          <button className="cart-btn">
            🛒 <span className="cart-count">{cart?.length || 0}</span>
          </button>
        </div>
      </div>
    </nav>
  );
}
